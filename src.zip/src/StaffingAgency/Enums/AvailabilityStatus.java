/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package StaffingAgency.Enums;

/**
 *
 * @author abhit
 */
public enum AvailabilityStatus {
    AVAILABLE,
    ASSIGNED,
    ON_LEAVE,
    UNAVAILABLE
}
